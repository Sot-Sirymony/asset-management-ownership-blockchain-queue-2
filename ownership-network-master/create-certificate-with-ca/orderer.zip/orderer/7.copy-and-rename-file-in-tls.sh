cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/tlscacerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/ca.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/signcerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/server.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/keystore/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/server.key


cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/tlscacerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/ca.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/signcerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/server.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/keystore/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer2.ownify.com/tls/server.key


cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/tlscacerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/ca.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/signcerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/server.crt
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/keystore/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer3.ownify.com/tls/server.key
