mkdir ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/msp/tlscacerts
cp ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/orderers/orderer.ownify.com/tls/tlscacerts/* ${PWD}/../../channel/crypto-config/ordererOrganizations/ownify.com/msp/tlscacerts/tlsca.ownify.com-cert.pem
