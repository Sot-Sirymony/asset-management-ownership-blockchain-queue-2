import React from 'react'

export default function Delete() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M3 6.54085H5H21" stroke="#EC221F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 6.54085V4.54085C8 4.01041 8.21071 3.50171 8.58579 3.12663C8.96086 2.75156 9.46957 2.54085 10 2.54085H14C14.5304 2.54085 15.0391 2.75156 15.4142 3.12663C15.7893 3.50171 16 4.01041 16 4.54085V6.54085M19 6.54085V20.5408C19 21.0713 18.7893 21.58 18.4142 21.9551C18.0391 22.3301 17.5304 22.5408 17 22.5408H7C6.46957 22.5408 5.96086 22.3301 5.58579 21.9551C5.21071 21.58 5 21.0713 5 20.5408V6.54085H19Z" stroke="#EC221F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10 11.5408V17.5408" stroke="#EC221F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M14 11.5408V17.5408" stroke="#EC221F" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

  )
}
