// pages/admin/department/page.js

import DepartmentClient from "../../components/client/DepartmentListingClient";

export default function DepartmentPage() {
  return <DepartmentClient />;
}
