// pages/admin/asset/create/page.js

import CategoryCreateClient from "../../../components/client/AssetCreateClient";

export default function CategoryCreatePage() {
  return <CategoryCreateClient />;
}
