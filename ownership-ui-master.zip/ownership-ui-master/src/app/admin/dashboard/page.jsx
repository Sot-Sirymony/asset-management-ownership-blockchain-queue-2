// pages/admin/dashboard/page.js

import DashboardClient from "../../components/client/DashboardClient";

export default function DashboardPage() {
  return <DashboardClient />;
}
