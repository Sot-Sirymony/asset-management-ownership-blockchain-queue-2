// pages/admin/history/page.js

import HistoryClient from "../../components/client/HistoryClient";

export default function HistoryPage() {
  return <HistoryClient />;
}
