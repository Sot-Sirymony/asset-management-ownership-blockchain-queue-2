// pages/admin/asset/page.js

import CategoryListClient from "../../components/client/AssetRequestListClient";

export default function CategoryListPage() {
    return <CategoryListClient />;
}
