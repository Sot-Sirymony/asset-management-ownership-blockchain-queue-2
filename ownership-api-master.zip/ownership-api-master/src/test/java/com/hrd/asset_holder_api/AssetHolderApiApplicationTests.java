package com.hrd.asset_holder_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetHolderApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
