package com.hrd.asset_holder_api.service;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface AppUserService extends UserDetailsService {
}
