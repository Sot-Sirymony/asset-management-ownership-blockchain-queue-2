package com.hrd.asset_holder_api.service;

public interface AdminService {
    void enrollService();
}
