package com.hrd.asset_holder_api.repository;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AssetRepository {
}
